package app.test.com.washtestapp.common;

public class IntentHelper {
    public static final String EXTRA_WASH_POS="wash_pos";
}
