package app.test.com.washtestapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import java.util.List;

import app.test.com.washtestapp.adapters.WashAdapter;
import app.test.com.washtestapp.common.IntentHelper;
import app.test.com.washtestapp.models.Wash;

public class WashListActivity extends AppCompatActivity {

    private List<String> elements;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wash_list);

        RecyclerView rvWashes=findViewById(R.id.rvWashes);
        rvWashes.setHasFixedSize(true);
        rvWashes.setLayoutManager(new LinearLayoutManager(this));
        rvWashes.setAdapter(new WashAdapter(Wash.getAllWashes(this), new WashAdapter.OnWashClickListener() {
            @Override
            public void onWashClick(int washPos) {
                startActivity(new Intent(WashListActivity.this, WashDetailActivity.class)
                    .putExtra(IntentHelper.EXTRA_WASH_POS, washPos));
            }
        }));
        rvWashes.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL ));
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        switch (item.getItemId()){
            case R.id.menu_add:
                addElement();
                return true;
            case R.id.menu_edit:
                editElement();
                return true;
            case R.id.menu_del:
                deleteElement();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

    private void addElement() {
        elements.add("New element");
        adapter.notifyDataSetChanged();
    }

    private void editElement() {
        elements.set(0,"Edited");
        adapter.notifyDataSetChanged();
    }


    private void deleteElement() {
        elements.clear();
        adapter.notifyDataSetChanged();
    }
}
